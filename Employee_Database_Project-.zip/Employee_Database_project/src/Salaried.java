/*
    Name: Alexander Duke
    Date: 8/29/2026
    Assignment: SDC330L - Final Submit
 */

public class Salaried extends Employee{
    private double AnnualSalary;

    public Salaried (String name, String phoneNumber, String email, String address, String dateofBirth, double annualSalary) {
        super(name, phoneNumber, email, address, dateofBirth);
        AnnualSalary = annualSalary;
    }

    public double getAnnualSalary() {
        return AnnualSalary;
    }
    public void setAnnualSalary(double annualSalary) {
        AnnualSalary = annualSalary;
    }

    public String getEmployeeType() {
        return "\n|| Salary Employee ||";
    }

    @Override
    public double calculatePay() {
        rawPay = AnnualSalary / 52;
        return WageCalculator.round(rawPay, 2);
    }

    @Override
    public String toString() {
        return String.format(
            getEmployeeType() + super.getEmployeeInfo() +
            "\nAnnual Salary: " + AnnualSalary + 
            "\nWeekly Pay (Before Taxes): " + calculatePay());
    }
}