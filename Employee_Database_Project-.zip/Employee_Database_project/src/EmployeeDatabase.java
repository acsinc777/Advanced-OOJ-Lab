/*
    Name: Alexander Duke
    Date: 8/29/2026
    Assignment: SDC330L - Final Submit
 */
import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;
public class EmployeeDatabase {
    public static boolean createTable(Connection conn) {
        //Employee Table
        String employeeTable = 
        "CREATE TABLE IF NOT EXISTS Employee (\n" +
        "   EmployeeID integer PRIMARY KEY AUTOINCREMENT,\n" +
        "   EmployeeName varchar(150) NOT NULL,\n" +
        "   PhoneNumber varchar(20) UNIQUE,\n" +
        "   Email varchar(50) UNIQUE,\n" +
        "   Address varchar(50),\n" +
        "   DateofBirth varchar(50) NOT NULL\n);";

        //Hourly Table
        String hourlyTable = 
        "CREATE TABLE IF NOT EXISTS Hourly (\n" +
        "   EmployeeID integer PRIMARY KEY,\n" +
        "   Hours integer,\n" +
        "   HourlyWage real NOT NULL,\n" +
        "   FOREIGN KEY(EmployeeID) REFERENCES Employee(EmployeeID) ON DELETE CASCADE);";

        //Commission Table
        String commTable = 
        "CREATE TABLE IF NOT EXISTS Commission (\n" +
        "   EmployeeID integer PRIMARY KEY,\n" +
        "   CommCount integer,\n" +
        "   BaseRate real NOT NULL,\n" +
        "   CommRate real NOT NULL,\n" +
        "   FOREIGN KEY(EmployeeID) REFERENCES Employee(EmployeeID) ON DELETE CASCADE);";

        //Salary Table
        String salaryTable = 
        "CREATE TABLE IF NOT EXISTS Salary (\n" +
        "   EmployeeID integer PRIMARY KEY,\n" +
        "   SalaryWage real NOT NULL,\n" +
        "   FOREIGN KEY(EmployeeID) REFERENCES Employee(EmployeeID) ON DELETE CASCADE);";

        try {
            Statement stmt = conn.createStatement();

            //turning on foreign keys
            stmt.execute("PRAGMA foreign_keys = ON;");

            //initialize tables
            stmt.execute(employeeTable);
            stmt.execute(hourlyTable);
            stmt.execute(commTable);
            stmt.execute(salaryTable);
            return true;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }
}
