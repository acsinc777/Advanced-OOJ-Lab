/*
    Name: Alexander Duke
    Date: 8/29/2026
    Assignment: SDC330L - Final Submit
 */
import java.sql.Connection; 
import java.sql.PreparedStatement; 
import java.sql.ResultSet; 
import java.sql.SQLException; 
import java.util.InputMismatchException; 
import java.util.Scanner;

public class DataController {
    private Scanner input = new Scanner(System.in);
    private Connection conn;

    public DataController(Connection conn) {
        this.conn = conn;
    }

    public void runCreation() {
        boolean run = true;
        while (run) {
            try {
                System.out.println("Enter what kind of Employee you would like to add: ");
                System.out.println("1.) Salaried Employee\n2.) Commissioned Employee\n3.) Hourly Employee\n4.) Return to Main Menu\n");
                int option = input.nextInt();
                input.nextLine();

                switch (option) {
                    case 1: //run creation method to make Salaried Employee
                        salaryEmp();
                        System.out.println("\nSalaried Employee Added to Database.");
                        break;
                    case 2: //run creation method to make Commissioned Employee
                        commissionEmp();
                        System.out.println("\nCommisioned Employee Added to Database.");
                        break;
                    case 3: //run creation method to make Hourly Employee
                        hourlyEmp();
                        System.out.println("\nHourly Employee Added to Database.");
                        break;
                    case 4: //return to main menu
                        run = false;
                        break;
                    default: //invalid entry
                        System.out.println("Invalid option.");
                }
            } catch (InputMismatchException e) {
                System.err.printf("%nException: %s%n", e);
                input.nextLine();
                System.out.println("Use numbers only to enter a valid option.");
                System.out.println();
            } catch (SQLException e) {
                System.err.println("Database Error: " + e.getMessage());
            }
        }
    }

    //Create Salaried Employee
    private void salaryEmp() throws SQLException {
        System.out.println("Enter Employee's First & Last Name (Ensure there is a space between the names): ");
        String name = input.nextLine();
        System.out.println("Enter Employee's Phone Number in the (###)-###-#### format: ");
        String phoneNumber = input.nextLine();
        System.out.println("Enter Employee's Email Address: ");
        String email = input.nextLine();
        System.out.println("Enter Employee's Current Residence: ");
        String address = input.nextLine();
        System.out.println("Enter Employee's Date of Birth in the ##/##/#### format: ");
        String dateofBirth = input.nextLine();
        System.out.println("Enter Employee's Annual Salary: ");
        Double annualSalary = input.nextDouble();
        input.nextLine();

        int employeeID = insertEmployee(name, phoneNumber, email, address, dateofBirth);

        String sql = "INSERT INTO Salary(EmployeeID, SalaryWage) " + "VALUES (?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) { 
            pstmt.setInt(1, employeeID); 
            pstmt.setDouble(2, annualSalary); 
            pstmt.executeUpdate(); 
        } 
    }

    //Create Commissioned Employee
    private void commissionEmp() throws SQLException {
        System.out.println("Enter Employee's First & Last Name (Ensure there is a space between the names): ");
        String name = input.nextLine();
        System.out.println("Enter Employee's Phone Number in the (###)-###-#### format: ");
        String phoneNumber = input.nextLine();
        System.out.println("Enter Employee's Email Address: ");
        String email = input.nextLine();
        System.out.println("Enter Employee's Current Residence: ");
        String address = input.nextLine();
        System.out.println("Enter Employee's Date of Birth in the ##/##/#### format: ");
        String dateofBirth = input.nextLine();
        System.out.println("Enter Employee's Amount of Commissions This Week: ");
        int commissionAmount = input.nextInt();
        input.nextLine();
        System.out.println("Enter Employee's Base Commission Rate: ");
        int baseRate = input.nextInt();
        input.nextLine();
        System.out.println("Enter Employee's Commission Rate by percent (%#.##): ");
        double commissionRate = input.nextDouble();
        input.nextLine();

        int employeeID = insertEmployee(name, phoneNumber, email, address, dateofBirth);

        String sql = "INSERT INTO Commission " + "(EmployeeID, CommCount, BaseRate, CommRate) " + "VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) { 
            pstmt.setInt(1, employeeID); 
            pstmt.setInt(2, commissionAmount); 
            pstmt.setDouble(3, baseRate); 
            pstmt.setDouble(4, commissionRate); 
            pstmt.executeUpdate(); 
        } 
    }

    //Create Hourly Employee
    private void hourlyEmp() throws SQLException {
        System.out.println("Enter Employee's First & Last Name (Ensure there is a space between the names): ");
        String name = input.nextLine();
        System.out.println("Enter Employee's Phone Number in the (###)-###-#### format: ");
        String phoneNumber = input.nextLine();
        System.out.println("Enter Employee's Email Address: ");
        String email = input.nextLine();
        System.out.println("Enter Employee's Current Residence: ");
        String address = input.nextLine();
        System.out.println("Enter Employee's Date of Birth in the ##/##/#### format: ");
        String dateofBirth = input.nextLine();
        System.out.println("Enter Number of Hours Employee is Scheduled For: ");
        int hours = input.nextInt();
        input.nextLine();
        System.out.println("Enter Employee's Hourly Rate: ");
        double hourlyPay = input.nextDouble();
        input.nextLine();

        int employeeID = insertEmployee( name, phoneNumber, email, address, dateofBirth );

        String sql = "INSERT INTO Hourly(EmployeeID, Hours, HourlyWage) " + "VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) { 
            pstmt.setInt(1, employeeID); 
            pstmt.setDouble(2, hours); 
            pstmt.setDouble(3, hourlyPay); 
            pstmt.executeUpdate(); 
        } 
    }

    //Insert Employee
    private int insertEmployee( String name, String phoneNumber, String email, String address, String dateofBirth) throws SQLException {
        String sql = "INSERT INTO Employee " + "(EmployeeName, PhoneNumber, Email, Address, DateofBirth) " + "VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement( sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, name); 
            pstmt.setString(2, phoneNumber); 
            pstmt.setString(3, email); 
            pstmt.setString(4, address); 
            pstmt.setString(5, dateofBirth); pstmt.executeUpdate();

            try (ResultSet rs = pstmt.getGeneratedKeys()) { 
                if (rs.next()) { 
                    return rs.getInt(1); 
                } 
            } 
        } 
        throw new SQLException("Employee could not be created.");
    }

    //Display All Employees
    public void displayEmployees() throws SQLException {
        String query = "SELECT e.EmployeeID, e.EmployeeName, e.PhoneNumber, " + 
            "e.Email, e.Address, e.DateofBirth, " + 
            "h.Hours, h.HourlyWage, " + 
            "c.CommCount, c.BaseRate, c.CommRate, " + 
            "s.SalaryWage " + 
            "FROM Employee e " + 
            "LEFT JOIN Hourly h ON e.EmployeeID = h.EmployeeID " + 
            "LEFT JOIN Commission c ON e.EmployeeID = c.EmployeeID " + 
            "LEFT JOIN Salary s ON e.EmployeeID = s.EmployeeID";

        try (PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery()) {
                boolean foundEmployee = false;

                while (rs.next()) {
                    foundEmployee = true;

                    if (rs.getObject("SalaryWage") != null) { 
                        System.out.println( new Salaried( rs.getString("EmployeeName"), 
                                                        rs.getString("PhoneNumber"), 
                                                        rs.getString("Email"), 
                                                        rs.getString("Address"), 
                                                        rs.getString("DateofBirth"), 
                                                        rs.getDouble("SalaryWage") ) );
                    } else if (rs.getObject("CommCount") != null) { 
                        System.out.println( new Commission( rs.getString("EmployeeName"), 
                                                        rs.getString("PhoneNumber"), 
                                                        rs.getString("Email"), 
                                                        rs.getString("Address"), 
                                                        rs.getString("DateofBirth"), 
                                                        rs.getInt("CommCount"), 
                                                        rs.getDouble("BaseRate"), 
                                                        rs.getDouble("CommRate") ) );
                    } else if (rs.getObject("Hours") != null) { 
                        System.out.println( new Hourly( rs.getString("EmployeeName"), 
                                                    rs.getString("PhoneNumber"), 
                                                    rs.getString("Email"), 
                                                    rs.getString("Address"), 
                                                    rs.getString("DateofBirth"), 
                                                    rs.getDouble("Hours"), 
                                                    rs.getDouble("HourlyWage") ) );
                    }
                    System.out.println("----------------------");
                } if (!foundEmployee) { 
                    System.out.println("No Employees Listed in Database.");
                }
            }
        }

        //Edit or Delete Employee
        public void editEmployee() throws SQLException {
            String query = "SELECT EmployeeID, EmployeeName FROM Employee";
            try (PreparedStatement pstmt = conn.prepareStatement(query); 
                ResultSet rs = pstmt.executeQuery()) {
                    System.out.println("\n--- Current Employees ---"); 
                    while (rs.next()) { 
                        System.out.printf( "%d: %s%n", rs.getInt("EmployeeID"), rs.getString("EmployeeName") );
                    }
                }

                System.out.print("\nEnter Employee ID to edit/delete: "); 
                int employeeID = input.nextInt(); 
                input.nextLine(); 
                
                System.out.println("\n1. Edit"); 
                System.out.println("2. Delete"); 
                System.out.println("3. Cancel"); 
                int choice = input.nextInt(); 
                input.nextLine();

                if (choice == 2) { 
                    String deleteEmployee = "DELETE FROM Employee WHERE EmployeeID = ?"; 
                    try (PreparedStatement pstmt = conn.prepareStatement(deleteEmployee)) { 
                        pstmt.setInt(1, employeeID); 
                        pstmt.executeUpdate(); 
                    }

                    System.out.println("Employee deleted."); 
                    return;
                } else if (choice != 1) {
                    System.out.println("Action Canceled.");
                    return;
                }

                //Choose Employee Type
                System.out.println("\nWhat type of employee is being edited?"); 
                System.out.println("1. Salaried"); 
                System.out.println("2. Commissioned"); 
                System.out.println("3. Hourly");

                int type = input.nextInt(); 
                input.nextLine();

                //Update Employee Information
                System.out.print("New Name: "); 
                String name = input.nextLine(); 
                System.out.print("New Phone: "); 
                String phone = input.nextLine(); 
                System.out.print("New Email: "); 
                String email = input.nextLine();
                System.out.print("New Address: "); 
                String address = input.nextLine(); 
                System.out.print("New Date of Birth: "); 
                String dateofBirth = input.nextLine();

                String updateEmployee = "UPDATE Employee SET " + "EmployeeName = ?, " + "PhoneNumber = ?, " + "Email = ?, " + "Address = ?, " + "DateofBirth = ? " + "WHERE EmployeeID = ?";
                try (PreparedStatement pstmt = conn.prepareStatement(updateEmployee)) { 
                    pstmt.setString(1, name); 
                    pstmt.setString(2, phone); 
                    pstmt.setString(3, email); 
                    pstmt.setString(4, address); 
                    pstmt.setString(5, dateofBirth); 
                    pstmt.setInt(6, employeeID);
                    pstmt.executeUpdate();
                }

                //Update Specific Employee Type
                switch (type) {
                    case 1: //Salaried
                        System.out.print("New Annual Salary: "); 
                        double salary = input.nextDouble(); 
                        input.nextLine(); 
                        String updateSalary = "UPDATE Salary SET SalaryWage = ? " + "WHERE EmployeeID = ?";
                        try (PreparedStatement pstmt = conn.prepareStatement(updateSalary)) { 
                            pstmt.setDouble(1, salary); 
                            pstmt.setInt(2, employeeID); 
                            pstmt.executeUpdate();
                        }
                        break;
                    case 2: //Commissioned
                        System.out.print("New Commission Amount: "); 
                        int commissionAmount = input.nextInt(); 
                        System.out.print("New Base Rate: "); 
                        double baseRate = input.nextDouble(); 
                        System.out.print("New Commission Rate: "); 
                        double commissionRate = input.nextDouble(); 
                        input.nextLine();
                        String updateCommission = "UPDATE Commission SET " + "CommCount = ?, " + "BaseRate = ?, " + "CommRate = ? " + "WHERE EmployeeID = ?";
                        try (PreparedStatement pstmt = conn.prepareStatement(updateCommission)) { 
                            pstmt.setInt(1, commissionAmount); 
                            pstmt.setDouble(2, baseRate); 
                            pstmt.setDouble(3, commissionRate); 
                            pstmt.setInt(4, employeeID); 
                            pstmt.executeUpdate();
                        }
                        break;
                    case 3: //Hourly
                        System.out.print("New Hours: "); 
                        double hours = input.nextDouble(); 
                        System.out.print("New Hourly Wage: "); 
                        double hourlyWage = input.nextDouble(); 
                        input.nextLine(); 
                        String updateHourly = "UPDATE Hourly SET " + "Hours = ?, " + "HourlyWage = ? " + "WHERE EmployeeID = ?";
                        try (PreparedStatement pstmt = conn.prepareStatement(updateHourly)) { 
                            pstmt.setDouble(1, hours); 
                            pstmt.setDouble(2, hourlyWage); 
                            pstmt.setInt(3, employeeID); 
                            pstmt.executeUpdate();
                        }
                        break;
                    default:
                        System.out.println("Invalid Option. Pick from the numbered selection.");
                        break;
                }

                System.out.println("Employee updated.");
            }
        }
