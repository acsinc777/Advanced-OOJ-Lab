/*
    Name: Alexander Duke
    Date: 8/27/2026
    Assignment: SDC330L - Project Part 4
 */

public class Commission extends Employee {
    private int CommissionAmount;
    private double BaseRate;
    private double CommissionRate;

    public Commission(String name, String phoneNumber, String email, String address, String dateofBirth, int commissionAmount, double baseRate, double commissionRate) {
        super(name, phoneNumber, email, address, dateofBirth);
        CommissionAmount = commissionAmount;
        BaseRate = baseRate;
        CommissionRate = commissionRate;
    }

    public int getCommissionAmount() {
        return CommissionAmount;
    }
    public void setCommissionAmount(int commissionAmount) {
        CommissionAmount = commissionAmount;
    }

    public double getBaseRate() {
        return BaseRate;
    }
    public void setBaseRate(double baseRate) {
        BaseRate = baseRate;
    }

    public double getCommissionRate() {
        return CommissionRate;
    }
    public void setCommissionRate(double commissionRate) {
        CommissionRate = commissionRate;
    }

    public String getEmployeeType() {
        return "\n|| Commissioned Employee ||";
    }

    @Override
    public double calculatePay() {
        rawPay = (CommissionRate * CommissionAmount) + BaseRate;
        return WageCalculator.round(rawPay, 2);
    }

    @Override
    public String toString() {
        return String.format(
            getEmployeeType() + super.getEmployeeInfo() +
            "\nBase Rate: " + BaseRate + 
            "\nCommission Rate: " + CommissionRate +
            "\nCommissions This Week: " + CommissionAmount +
            "\nPay Out This Week (Before Taxes): " + calculatePay());
    }
}
