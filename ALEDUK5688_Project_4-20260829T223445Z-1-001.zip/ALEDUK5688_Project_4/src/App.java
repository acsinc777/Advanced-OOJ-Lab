/*
    Name: Alexander Duke
    Date: 8/27/2026
    Assignment: SDC330L - Project Part 4
 */

 import java.util.Scanner;
 import java.util.InputMismatchException;
 import java.sql.Connection;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Alexander Duke - Week 4 Project");

        //Initiating objects with constructors
        //Updated objects to have more realistic information
        Scanner scanner = new Scanner(System.in);
        Connection conn = SQLiteDatabase.connect("employees.db");
        EmployeeDatabase.createTable(conn);
        DataController cntrl = new DataController(conn);
    
        //Loop Condition
        boolean con = true;

        System.out.println("\n-----------------------------------------------------------------------");
        System.out.println("Welcome to Employee Data Base - Phase 4");
        System.out.println("This Project is in Development. All code and layouts might be changed.");
        System.out.println("-----------------------------------------------------------------------\n");
        Thread.sleep(1000);

        while (con) {
            try {
                System.out.println("|| Main Menu ||");
                System.out.println("1.) Add Employee");
                System.out.println("2.) Edit Employee");
                System.out.println("3.) Display All Current Employee Information");
                System.out.println("4.) Exit & Close");

                int input = scanner.nextInt();

                switch (input) {
                    case 1:
                        cntrl.runCreation();
                        break;
                    case 2:
                        cntrl.editEmployee();
                        break;
                    case 3:
                        cntrl.displayEmployees();
                        break;
                    case 4: //exit function
                        System.out.println("Thank you.");
                        Thread.sleep(1000);
                        System.out.println("All Employee Information is Saved & Updated.");
                        Thread.sleep(1000);
                        System.out.println("Exiting Program Now.");
                        Thread.sleep(1000);
                        con = false;
                        break;
                    default: //in case of invalid option selection
                        System.out.println("Invalid Option. Choose from the menu please.");
                }
            } catch (InputMismatchException e) {
                System.err.printf("%nException: %s%n", e);
                scanner.nextLine();
                System.out.println("Use Numbers Only to Enter a Valid Option.");
                System.out.println();
            }
        }

    }
}
