/*
    Name: Alexander Duke
    Date: 8/27/2026
    Assignment: SDC330L - Project Part 4
 */

public abstract class Employee implements CalculatePay {
    private String Name;
    private String PhoneNumber;
    private String Email;
    private String Address;
    private String DateofBirth;

    //Pre-emptively set Employee constructor as Protected
    //Getters and setters are public for database implementation later on
    protected Employee(String name, String phoneNumber, String email, String address, String dateofBirth) {
        Name = name;
        PhoneNumber = phoneNumber;
        Email = email;
        Address = address;
        DateofBirth = dateofBirth;
    }

    //Getters and Setters
    public String getName() {
        return Name;
    }
    public void setName(String name) {
        Name = name;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    public String getEmail() {
        return Email;
    }
    public void setEmail(String email) {
        Email = email;
    }

    public String getAddress() {
        return Address;
    }
    public void setAddress(String address) {
        Address = address;
    }

    public String getDateofBirth() {
        return DateofBirth;
    }
    public void setDateofBirth(String dateofBirth) {
        DateofBirth = dateofBirth;
    }

    public double rawPay;

    protected String getEmployeeInfo() {
        return String.format (
            "\nEmployee Name: " + Name + 
            "\nPhone Number: " + PhoneNumber + 
            "\nEmail: " + Email + 
            "\nAddress: " + Address + 
            "\nDate of Birth: " + DateofBirth);
    }

    @Override
    public String toString() {
        return getEmployeeInfo();
    }
}