/*
    Name: Alexander Duke
    Date: 8/20/2026
    Assignment: SDC330L - Project Part 3
 */

 //New interface class allows for calculatePay method to be
 //inherited across all needed classes that extend Employee.
 //Technically, my program already did this with the public abstract
 //double, however this new layout allows for polymorphism and abstraction
 //throughout the program in a more diagetic and structurally sound way
 public interface CalculatePay {
    public double calculatePay();
 }