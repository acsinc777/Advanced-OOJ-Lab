/*
    Name: Alexander Duke
    Date: 8/20/2026
    Assignment: SDC330L - Project Part 3
 */

 import java.util.Scanner;
 import java.util.InputMismatchException;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Alexander Duke - Week 3 Project");

        //Initiating objects with constructors
        //Updated objects to have more realistic information
        Scanner scanner = new Scanner(System.in);
        DataController controldata = new DataController();
        Employee hourly = new Hourly("Rowan Hawthorne", "888-888-8888", "rhawthorne@realmail.com", "123 Street Home", "01/01/2001", 40.00, 18.42);
        Employee salaried = new Salaried("Lauren Selk", "555-555-5555", "ls1996@realmail.com", "999 Circle Road", "12/24/1996", 89000);
        Employee commission = new Commission("Rachel Oates", "333-333-3333", "oatesra@realmail.com", "456 City Street", "09/22/2001", 4, 300.75, 0.08);

        //Loop Condition
        boolean con = true;

        System.out.println("\n-----------------------------------------------------------------------");
        System.out.println("Welcome to Employee Data Base - Phase 3");
        System.out.println("This Project is in Development. All code and layouts might be changed.");
        System.out.println("-----------------------------------------------------------------------\n");
        Thread.sleep(1000);

        while (con) {
            try {
                System.out.println("|| Main Menu ||");
                System.out.println("1.) Hourly Employee Information");
                System.out.println("2.) Salaried Employee Information");
                System.out.println("3.) Commission Employee Information");
                System.out.println("4.) Add Employee to Database");
                System.out.println("5.) Display All Employees");
                System.out.println("6.) Exit & Close");

                int input = scanner.nextInt();

                switch (input) {
                    case 1: //display hourly employee. will be replaced with a 'View Employees' option.
                        System.out.println(hourly);
                        Pause.buffer();
                        break;
                    case 2: //display salaried employee. will be replaced with a 'Edit'
                        System.out.println(salaried);
                        Pause.buffer();
                        break;
                    case 3:
                        System.out.println(commission);
                        Pause.buffer();
                        break;
                    case 4:
                        controldata.runCreation();
                        break;
                    case 5:
                        controldata.displayEmployees();
                        Pause.buffer();
                        break;
                    case 6: //exit function
                        System.out.println("Thank you.");
                        Thread.sleep(1000);
                        System.out.println("All Employee Information is Saved & Updated.");
                        Thread.sleep(1000);
                        System.out.println("Exiting Program Now.");
                        Thread.sleep(1000);
                        con = false;
                        break;
                    default: //in case of invalid option selection
                        System.out.println("Invalid Option. Choose from the menu please.");
                }
            } catch (InputMismatchException e) {
                System.err.printf("%nException: %s%n", e);
                scanner.nextLine();
                System.out.println("Use Numbers Only to Enter a Valid Option.");
                System.out.println();
            }
        }

    }
}
