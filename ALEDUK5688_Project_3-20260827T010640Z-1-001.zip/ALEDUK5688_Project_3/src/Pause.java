/*
    Name: Alexander Duke
    Date: 8/20/2026
    Assignment: SDC330L - Project Part 3
 */
import java.util.Scanner;
public class Pause {
    private static final Scanner scanner = new Scanner(System.in);

    public static void buffer() {
        System.out.println("\nPress Enter to return to the menu.");
        scanner.nextLine();
    }
}
