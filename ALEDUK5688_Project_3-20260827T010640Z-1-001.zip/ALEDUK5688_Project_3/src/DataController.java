/*
    Name: Alexander Duke
    Date: 8/20/2026
    Assignment: SDC330L - Project Part 3
 */
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class DataController {
    public ArrayList<Employee> employees = new ArrayList<Employee>();

    private Scanner input = new Scanner(System.in);

    public void runCreation() {
        boolean run = true;
        while (run) {
            try {
                System.out.println("Enter what kind of Employee you would like to add: ");
                System.out.println("1.) Salaried Employee\n2.) Commissioned Employee\n3.) Hourly Employee\n4.) Return to Main Menu\n");
                int option = input.nextInt();
                input.nextLine();

                switch (option) {
                    case 1: //run creation method to make Salaried Employee
                        salaryEmp();
                        System.out.println("\nSalaried Employee Added to Database.");
                        break;
                    case 2: //run creation method to make Commissioned Employee
                        commissionEmp();
                        System.out.println("\nCommisioned Employee Added to Database.");
                        break;
                    case 3: //run creation method to make Hourly Employee
                        hourlyEmp();
                        System.out.println("\nHourly Employee Added to Database.");
                        break;
                    case 4: //return to main menu
                        run = false;
                        break;
                    default: //invalid entry
                        System.out.println("Invalid option.");
                }
            } catch (InputMismatchException e) {
                System.err.printf("%nException: %s%n", e);
                input.nextLine();
                System.out.println("Use numbers only to enter a valid option.");
                System.out.println();
            }
        }
    }

    private Employee salaryEmp() {
        System.out.println("Enter Employee's First & Last Name (Ensure there is a space between the names): ");
        String name = input.nextLine();
        System.out.println("Enter Employee's Phone Number in the (###)-###-#### format: ");
        String phoneNumber = input.nextLine();
        System.out.println("Enter Employee's Email Address: ");
        String email = input.nextLine();
        System.out.println("Enter Employee's Current Residence: ");
        String address = input.nextLine();
        System.out.println("Enter Employee's Date of Birth in the ##/##/#### format: ");
        String dateofBirth = input.nextLine();
        System.out.println("Enter Employee's Annual Salary: ");
        Double annualSalary = input.nextDouble();
        input.nextLine();
        Salaried salary = new Salaried(name, phoneNumber, email, address, dateofBirth, annualSalary);
        employees.add(salary);
        return salary;
    }

    private Employee commissionEmp() {
        System.out.println("Enter Employee's First & Last Name (Ensure there is a space between the names): ");
        String name = input.nextLine();
        System.out.println("Enter Employee's Phone Number in the (###)-###-#### format: ");
        String phoneNumber = input.nextLine();
        System.out.println("Enter Employee's Email Address: ");
        String email = input.nextLine();
        System.out.println("Enter Employee's Current Residence: ");
        String address = input.nextLine();
        System.out.println("Enter Employee's Date of Birth in the ##/##/#### format: ");
        String dateofBirth = input.nextLine();
        System.out.println("Enter Employee's Amount of Commissions This Week: ");
        int commissionAmount = input.nextInt();
        input.nextLine();
        System.out.println("Enter Employee's Base Commission Rate: ");
        int baseRate = input.nextInt();
        input.nextLine();
        System.out.println("Enter Employee's Commission Rate by percent (%#.##): ");
        double commissionRate = input.nextDouble();
        input.nextLine();
        Commission comm = new Commission(name, phoneNumber, email, address, dateofBirth, commissionAmount, baseRate, commissionRate);
        employees.add(comm);
        return comm;
    }

    private Employee hourlyEmp() {
        System.out.println("Enter Employee's First & Last Name (Ensure there is a space between the names): ");
        String name = input.nextLine();
        System.out.println("Enter Employee's Phone Number in the (###)-###-#### format: ");
        String phoneNumber = input.nextLine();
        System.out.println("Enter Employee's Email Address: ");
        String email = input.nextLine();
        System.out.println("Enter Employee's Current Residence: ");
        String address = input.nextLine();
        System.out.println("Enter Employee's Date of Birth in the ##/##/#### format: ");
        String dateofBirth = input.nextLine();
        System.out.println("Enter Number of Hours Employee is Scheduled For: ");
        int hours = input.nextInt();
        input.nextLine();
        System.out.println("Enter Employee's Hourly Rate: ");
        double hourlyPay = input.nextDouble();
        input.nextLine();
        Hourly hour = new Hourly(name, phoneNumber, email, address, dateofBirth, hours, hourlyPay);
        employees.add(hour);
        return hour;
    }

    public void displayEmployees() {
        if (employees.isEmpty()) {
            System.out.println("No Employees Listed in Database.");
            return;
        }
        for (Employee e : employees) {
            System.out.println(e);
            System.out.println("----------------------");
        }
    }
}
