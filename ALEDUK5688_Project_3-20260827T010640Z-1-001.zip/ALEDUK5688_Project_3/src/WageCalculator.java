/*
    Name: Alexander Duke
    Date: 8/20/2026
    Assignment: SDC330L - Project Part 3
 */
import java.math.BigDecimal;
import java.math.RoundingMode;

//While testing the program, I noticed the way the Pay was adding together
//resulted in a long decimal. I went ahead and did research into BigDecimal
//to help round. Since Pay being calculated requires the objects to be double, meaning they
//have to be treated as formattable numbers, I couldn't just change it to float or string.
//Float can have bugs with compounded numbers being added, and Strings can't be added together numerically.
//So... now I have this.
public class WageCalculator {
    public static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = BigDecimal.valueOf(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }
}
