/*
    Name: Alexander Duke
    Date: 7/31/2026
    Assignment: SDC330L - Project Part 1
 */

public class Commission extends Employee {
    private int Commissions;
    private double BaseRate;
    private double CommissionRate;

    public Commission(String name, String phoneNumber, String email, String address, String dateofBirth, int commissions, double baseRate, double commissionRate) {
        super(name, phoneNumber, email, address, dateofBirth);
        Commissions = commissions;
        BaseRate = baseRate;
        CommissionRate = commissionRate;
    }

    public int getCommissions() {
        return Commissions;
    }
    public void setCommissions(int commissions) {
        Commissions = commissions;
    }

    public double getBaseRate() {
        return BaseRate;
    }
    public void setBaseRate(double baseRate) {
        BaseRate = baseRate;
    }

    public double getCommissionRate() {
        return CommissionRate;
    }
    public void setCommissionRate(double commissionRate) {
        CommissionRate = commissionRate;
    }

    public String getEmployeeType() {
        return "\n|| Commissioned Employee ||";
    }

    @Override
    public double calculatePay() {
        return (CommissionRate * Commissions) + BaseRate;
    }

    @Override
    public String toString() {
        return String.format(
            getEmployeeType() + super.getEmployeeInfo() +
            "\nBase Rate: " + BaseRate + 
            "\nCommission Rate: " + CommissionRate +
            "\nCommissions This Week: " + Commissions +
            "\nPay Out This Week (Before Taxes): " + calculatePay());
    }
}
