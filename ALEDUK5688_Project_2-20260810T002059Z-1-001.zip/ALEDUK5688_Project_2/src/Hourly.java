/*
    Name: Alexander Duke
    Date: 8/7/2026
    Assignment: SDC330L - Project Part 2
 */

public class Hourly extends Employee {
    private double Hours;
    private double HourlyPay;

    public Hourly(String name, String phoneNumber, String email, String address, String dateofBirth, double hours, double hourlyPay) {
        super(name, phoneNumber, email, address, dateofBirth);
        Hours = hours;
        HourlyPay = hourlyPay;
    }

    public double getHours() {
        return Hours;
    }
    public void setHours(double hours) {
        Hours = hours;
    }

    public double getHourlyPay() {
        return HourlyPay;
    }
    public void setHourlyPay(double hourlyPay) {
        HourlyPay = hourlyPay;
    }

    @Override
    public String getEmployeeType() {
        return "\n|| Hourly Employee ||";
    }

    @Override
    public double calculatePay() {
        return HourlyPay * Hours;
    }

    @Override
    public String toString() {
        return String.format(
            getEmployeeType() + super.getEmployeeInfo() +
            "\nHourly Pay: " + HourlyPay + 
            "\nHours Scheduled: " + Hours +
            "\nWeekly Pay (Before Taxes): " + calculatePay());
    }
}


