/*
    Name: Alexander Duke
    Date: 8/7/2026
    Assignment: SDC330L - Project Part 2
 */

 import java.util.Scanner;
 import java.util.InputMismatchException;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Alexander Duke - Week 2 Project");

        //Initiating objects with constructors
        //Updated objects to have more realistic information
        Scanner scanner = new Scanner(System.in);
        Employee hourly = new Hourly("Rowan Hawthorne", "888-888-8888", "rhawthorne@realmail.com", "123 Street Home", "01/01/2001", 40.00, 18.42);
        Employee salaried = new Salaried("Lauren Selk", "555-555-5555", "ls1996@realmail.com", "999 Circle Road", "12/24/1996", 89000);
        Employee commission = new Commission("Rachel Oates", "333-333-3333", "oatesra@realmail.com", "456 City Street", "09/22/2001", 4, 300.75, 0.08);

        //Loop Condition
        boolean con = true;

        while (con) {
            try {
                System.out.println("\nWelcome to Employee Data Base - Phase 1");
                System.out.println("This Project is in Development. All code and layouts might be changed.");
                System.out.println("|| Main Menu ||");
                System.out.print("1.) Hourly Employee Information\n2.) Salaried Employee Information\n3.) Commissioned Employee Information\n4.) Exit Program\n");
                int input = scanner.nextInt();

                switch (input) {
                    case 1:
                        System.out.println(hourly);
                        break;
                    case 2:
                        System.out.println(salaried);
                        break;
                    case 3:
                        System.out.println(commission);
                        break;
                    case 4:
                        System.out.println("Exiting Program. Thank you.");
                        con = false;
                        break;
                    default:
                        System.out.println("Invalid Option. Choose from the menu please.");
                }
            } catch (InputMismatchException e) {
                System.err.printf("%nException: %s%n", e);
                scanner.nextLine();
                System.out.println("Use Numbers Only to Enter a Valid Option.");
                System.out.println();
            }
        }

    }
}
